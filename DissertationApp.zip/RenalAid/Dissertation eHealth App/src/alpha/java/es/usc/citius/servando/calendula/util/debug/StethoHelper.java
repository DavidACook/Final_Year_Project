package es.usc.citius.servando.calendula.util.debug;

import android.content.Context;

public class StethoHelper implements StethoHelperInterface {
    @Override
    public void init(Context context) {
        // noop
    }
}
